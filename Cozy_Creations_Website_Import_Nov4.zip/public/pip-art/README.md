# Official Pip / Cloudmeadow artwork lives here

Drop the owner's official character and Cloudmeadow art in this folder, then set
the matching `asset` field in `src/data/catalog.ts` (`pipHeroArt` for the hero,
`pipArtwork` for the four gallery frames):

    /pip-art/<name>.png

Expected names (see `ASSET-INTAKE.md`):
- `pip-character.png` — hero character art
- `pip-book-cover.png` — book cover for the artwork gallery
- `pip-character-sheet.png` — character sheet
- `pip-sample-page.png` — sample coloring page
- `pip-cloudmeadow.png` — Cloudmeadow scene

Guidance: portrait 3:4, PNG or JPG, at least 1600 px tall, sRGB, under ~2 MB.
Official art only — never a stand-in or generated image.

Full instructions: `ASSET-INTAKE.md` at the repo root.

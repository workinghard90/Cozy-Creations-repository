# Official book covers live here

Drop the owner's official cover image in this folder, named after the title's
slug, then point that title's `coverAsset` field in `src/data/catalog.ts` at it:

    /covers/<slug>.png

Example: `public/covers/pips-cloud-magic-coloring-book.png`
→ `coverAsset: "/covers/pips-cloud-magic-coloring-book.png"`

Guidance: portrait 3:4, PNG or JPG, at least 1600 px tall, sRGB, under ~2 MB.
Use the official cover only — never a stand-in or generated image.

Full instructions: `ASSET-INTAKE.md` at the repo root.

# Cozy Creations by Autumn™

Website source prepared from the owner's CTO.new export. This repository is separate from WEC.

## Deployment status

This is a **source import**, not a verified Cloudflare deployment. The original project uses TanStack Start with a Bun runtime. It must be adapted and tested for Cloudflare Workers before deployment.

Do not run CTO-specific publishing scripts or forward environment variables. No credentials should be committed.
